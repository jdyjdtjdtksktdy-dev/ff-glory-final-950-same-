const express=require("express");
const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

const app=express();
const PORT=Number(process.env.PORT||3000);
const DB=path.join(__dirname,"data","db.json");
const API_KEY=process.env.FAMGATEWAY_API_KEY||"";
const SITE_NAME=process.env.SITE_NAME||"FF GLORY";
const MERCHANT_UPI=process.env.MERCHANT_UPI||"ratan143@fam";

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));

function db(){
  try{return JSON.parse(fs.readFileSync(DB,"utf8"))}
  catch(e){return {users:[],orders:[],coupons:[],transactions:[]}}
}
function save(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
function id(prefix){return prefix+"_"+crypto.randomBytes(8).toString("hex")}
function hashPassword(p,salt=crypto.randomBytes(16).toString("hex")){
  return salt+":"+crypto.scryptSync(p,salt,64).toString("hex")
}
function checkPassword(p,h){
  const [salt,key]=String(h).split(":");
  if(!salt||!key)return false;
  const got=crypto.scryptSync(p,salt,64);
  return crypto.timingSafeEqual(got,Buffer.from(key,"hex"));
}
function signSession(userId){
  const payload=Buffer.from(JSON.stringify({u:userId,t:Date.now()})).toString("base64url");
  const sig=crypto.createHmac("sha256",process.env.SESSION_SECRET||"ff-glory-local-secret").update(payload).digest("base64url");
  return payload+"."+sig;
}
function readSession(req){
  const raw=(req.headers.cookie||"").match(/ff_session=([^;]+)/)?.[1];
  if(!raw)return null;
  const [payload,sig]=raw.split(".");
  if(!payload||!sig)return null;
  const expected=crypto.createHmac("sha256",process.env.SESSION_SECRET||"ff-glory-local-secret").update(payload).digest("base64url");
  if(sig!==expected)return null;
  try{return JSON.parse(Buffer.from(payload,"base64url").toString()).u}catch(e){return null}
}
function currentUser(req){
  const uid=readSession(req); if(!uid)return null;
  const d=db(); return d.users.find(u=>u.id===uid)||null;
}
function setSession(res,userId){
  res.setHeader("Set-Cookie",`ff_session=${signSession(userId)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`);
}
function clearSession(res){
  res.setHeader("Set-Cookie","ff_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");
}
function publicUser(u){return {id:u.id,email:u.email,username:u.username,credits:u.credits||0}}
function packageFor(quantity){
  // Reference UI uses quantity 1–10 at ₹95 per quantity.
  // Business rule: every successfully verified payment adds EXACTLY 1 credit.
  if(!Number.isInteger(quantity) || quantity<1 || quantity>10) return null;
  const price=95*quantity;
  if(price>950) return null;
  return {quantity, price, credits:1};
}

async function famCreateOrder(amount, customerName){
  if(!API_KEY) throw new Error("Payment gateway key is not configured");
  const r=await fetch("https://famgateway.in/api/create-order",{
    method:"POST",
    headers:{"Content-Type":"application/json","X-Api-Key":API_KEY},
    body:JSON.stringify({
      amount,
      customer_name:customerName,
      redirect_url:"/payment-success"
    })
  });
  const text=await r.text();
  let data; try{data=JSON.parse(text)}catch(e){throw new Error("Gateway returned invalid JSON")}
  if(!r.ok || data.status!=="success") throw new Error(data.message||data.error||"Payment order creation failed");
  return data.data;
}
async function famVerifyOrder(orderId){
  const r=await fetch("https://famgateway.in/api/verify-order.php?order_id="+encodeURIComponent(orderId),{
    headers:{"X-Api-Key":API_KEY}
  });
  const text=await r.text(); let data;
  try{data=JSON.parse(text)}catch(e){return {status:"pending"}}
  return data;
}
function fulfill(orderId,status){
  const d=db();
  const o=d.orders.find(x=>x.id===orderId);
  if(!o || o.status==="paid") return o;
  if(status.status!=="success") return o;
  const gatewayAmount=Number(status.data?.amount ?? status.amount ?? 0);
  if(gatewayAmount && Math.round(gatewayAmount)!==Math.round(o.amount)) return o;
  o.status="paid";
  o.utr=status.data?.utr||status.utr||null;
  o.transactionId=status.data?.transaction_id||status.transaction_id||null;
  o.paidAt=new Date().toISOString();
  const u=d.users.find(x=>x.id===o.userId);
  if(u) u.credits=(u.credits||0)+o.credits;
  d.transactions.push({
    id:id("txn"),userId:o.userId,orderId:o.id,credits:o.credits,
    amount:o.amount,status:"paid",utr:o.utr,createdAt:o.paidAt
  });
  save(d);
  return o;
}

app.get("/api/config",(req,res)=>res.json({
  siteName:SITE_NAME,merchantUpi:MERCHANT_UPI,
  packages:Array.from({length:10},(_,i)=>({quantity:i+1,price:95*(i+1),credits:1}))
}));

app.post("/api/register",(req,res)=>{
  const {email,username,password}=req.body||{};
  if(!email||!username||!password||password.length<6)return res.status(400).json({error:"Enter valid details; password must be 6+ characters."});
  const d=db();
  if(d.users.some(u=>u.email.toLowerCase()===String(email).toLowerCase()))return res.status(409).json({error:"Email already registered"});
  const u={id:id("usr"),email:String(email).trim().toLowerCase(),username:String(username).trim(),passwordHash:hashPassword(String(password)),credits:0,createdAt:new Date().toISOString()};
  d.users.push(u);save(d);setSession(res,u.id);res.json({user:publicUser(u)});
});
app.post("/api/login",(req,res)=>{
  const {email,password}=req.body||{};const d=db();
  const u=d.users.find(x=>x.email.toLowerCase()===String(email||"").toLowerCase());
  if(!u||!checkPassword(String(password||""),u.passwordHash))return res.status(401).json({error:"Invalid email or password"});
  setSession(res,u.id);res.json({user:publicUser(u)});
});
app.post("/api/logout",(req,res)=>{clearSession(res);res.json({ok:true})});
app.get("/api/me",(req,res)=>{
  const u=currentUser(req); if(!u)return res.status(401).json({error:"not_signed_in"});
  res.json({user:publicUser(u)});
});

app.post("/api/create-payment",async(req,res)=>{
  try{
    const u=currentUser(req);if(!u)return res.status(401).json({error:"Please login"});
    const quantity=Number(req.body?.quantity);const pkg=packageFor(quantity);
    if(!pkg)return res.status(400).json({error:"Invalid package"});
    const localId=id("ord");
    const gateway=await famCreateOrder(pkg.price,u.username||u.email);
    const d=db();
    d.orders.push({
      id:localId,gatewayOrderId:gateway.order_id,userId:u.id,quantity:pkg.quantity,credits:1,
      amount:pkg.price,status:"pending",qrUrl:gateway.qr_url,
      checkoutUrl:gateway.checkout_url,upiIntent:gateway.upi_intent,
      payableAmount:Number(gateway.payable_amount||pkg.price),
      createdAt:new Date().toISOString(),expiresAt:gateway.expires_at_ist||null
    });
    save(d);
    res.json({
      orderId:localId,gatewayOrderId:gateway.order_id,
      quantity:pkg.quantity,credits:1,amount:pkg.price,payableAmount:Number(gateway.payable_amount||pkg.price),
      qrUrl:gateway.qr_url,checkoutUrl:gateway.checkout_url,upiIntent:gateway.upi_intent,
      expiresAt:gateway.expires_at_ist||null
    });
  }catch(e){res.status(502).json({error:e.message||"Payment gateway error"})}
});

app.get("/api/payment-status/:id",async(req,res)=>{
  try{
    const u=currentUser(req);if(!u)return res.status(401).json({error:"Please login"});
    const d=db();const o=d.orders.find(x=>x.id===req.params.id&&x.userId===u.id);
    if(!o)return res.status(404).json({error:"Order not found"});
    if(o.status==="paid")return res.json({status:"success",credits:o.credits,utr:o.utr});
    const status=await famVerifyOrder(o.gatewayOrderId);
    const done=fulfill(o.id,status);
    if(done.status==="paid")return res.json({status:"success",credits:done.credits,utr:done.utr});
    if(status.status==="expired"){o.status="expired";save(d);return res.json({status:"expired"})}
    res.json({status:"pending"});
  }catch(e){res.json({status:"pending"})}
});

app.get("/api/transactions",(req,res)=>{
  const u=currentUser(req);if(!u)return res.status(401).json({error:"Please login"});
  const d=db();res.json({transactions:d.transactions.filter(x=>x.userId===u.id).reverse().slice(0,50)});
});

app.post("/api/coupon/redeem",(req,res)=>{
  const u=currentUser(req);if(!u)return res.status(401).json({error:"Please login"});
  const code=String(req.body?.code||"").trim().toUpperCase();
  const d=db();const c=d.coupons.find(x=>x.code===code);
  if(!c||c.usedBy?.includes(u.id))return res.status(400).json({error:"Invalid or already used coupon"});
  c.usedBy=c.usedBy||[];c.usedBy.push(u.id);u.credits=(u.credits||0)+(c.credits||0);save(d);
  res.json({ok:true,credits:c.credits});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`${SITE_NAME} running on http://localhost:${PORT}`));
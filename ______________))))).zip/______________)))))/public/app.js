let state={user:null,qty:1,order:null,poll:null,timer:null,seconds:300};

const $=id=>document.getElementById(id);
const screens={
 login:"loginScreen",register:"registerScreen",home:"homeScreen",buy:"buyScreen",
 scanner:"scannerScreen",history:"historyScreen",coupon:"couponScreen",contact:"contactScreen"
};
function show(id){Object.values(screens).forEach(x=>$(x).classList.remove("active"));$(screens[id]).classList.add("active");$("nav").style.display=state.user&&id!=="login"&&id!=="register"?"grid":"none";window.scrollTo(0,0);if(id==="history")loadHistory()}
function go(id){show(id)}
function showAuth(id){show(id)}
function toast(msg){const t=$("toast");t.textContent=msg;t.className="show";setTimeout(()=>t.className="",2600)}
window.showToast=toast;

function renderPackages(){
 const box=$("packageList");
 Array.from({length:10},(_,i)=>({quantity:i+1,price:95*(i+1),credits:1})).forEach(p=>{
   const d=document.createElement("div");d.className="pkg";
   d.innerHTML=`<div><b>${p.quantity} Quantity</b><small>Basic Credit • ${p.credits} prime squad</small></div><button class="buyBtn">₹${p.price}</button>`;
   d.querySelector("button").onclick=()=>{state.qty=p.quantity;syncBuy();show("buy")};box.appendChild(d);
 });
}
function syncBuy(){
 $("qty").textContent=state.qty;$("total").textContent=95*state.qty;$("payNow").textContent=95*state.qty;$("payAmount").textContent=95*state.qty;
}
function changeQty(n){state.qty=Math.max(1,Math.min(10,state.qty+n));syncBuy()}
async function api(url,opt={}){const r=await fetch(url,{...opt,headers:{"Content-Type":"application/json",...(opt.headers||{})}});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||"Request failed");return d}

$("loginForm").addEventListener("submit",async e=>{
 e.preventDefault();try{const d=await api("/api/login",{method:"POST",body:JSON.stringify({email:$("loginEmail").value,password:$("loginPassword").value})});state.user=d.user;bootUser()}catch(x){toast(x.message)}
});
$("registerForm").addEventListener("submit",async e=>{
 e.preventDefault();const btn=e.target.querySelector("button");btn.textContent="Creating account…";
 try{const d=await api("/api/register",{method:"POST",body:JSON.stringify({username:$("regUsername").value,email:$("regEmail").value,password:$("regPassword").value})});state.user=d.user;bootUser()}catch(x){toast(x.message)}finally{btn.textContent="Create Account"}
});
async function bootUser(){
 $("welcomeName").textContent=state.user.username;$("userMini").textContent=state.user.username;$("creditStat").textContent=state.user.credits;
 renderPackages();syncBuy();show("home");
}
async function refreshMe(){try{const d=await api("/api/me");state.user=d.user;bootUser()}catch(e){show("login")}}
function launchBot(){if(!Number(state.user?.credits))return toast("No credits available");toast("Select a credit package to launch bots")}
async function openScanner(){
 try{
   stopPolling();$("scanStatus").className="scanStatus";$("scanStatus").innerHTML='<span class="spinner"></span> Creating secure payment…';show("scanner");
   const d=await api("/api/create-payment",{method:"POST",body:JSON.stringify({quantity:state.qty})});state.order=d;
   $("qr").src=d.qrUrl;$("openPay").href=d.checkoutUrl||d.upiIntent||"#";$("payAmount").textContent=d.payableAmount;
   $("scanStatus").innerHTML='<span class="spinner"></span> Waiting for payment…';
   startTimer();startPolling();
 }catch(e){$("scanStatus").textContent=e.message;toast(e.message)}
}
function startTimer(){clearInterval(state.timer);state.seconds=300;state.timer=setInterval(()=>{state.seconds--;const m=String(Math.floor(state.seconds/60)).padStart(2,"0"),s=String(state.seconds%60).padStart(2,"0");$("scanTimer").textContent=`${m}:${s}`;if(state.seconds<=0){clearInterval(state.timer);stopPolling();$("scanStatus").textContent="Payment session expired. Start again."}},1000)}
function startPolling(){clearInterval(state.poll);state.poll=setInterval(checkPayment,3000);checkPayment()}
async function checkPayment(){
 if(!state.order)return;
 try{
  const d=await api("/api/payment-status/"+encodeURIComponent(state.order.orderId));
  if(d.status==="success"){
   stopPolling();$("scanStatus").className="scanStatus ok";$("scanStatus").textContent=`✓ Real payment verified — 1 credit added`;await refreshMe();setTimeout(()=>show("home"),1800);
  }else if(d.status==="expired"){stopPolling();$("scanStatus").textContent="Payment expired. Please start a new payment."}
 }catch(e){}
}
function stopPolling(){clearInterval(state.poll);clearInterval(state.timer)}
async function loadHistory(){
 try{const d=await api("/api/transactions");const box=$("history");box.innerHTML=d.transactions.length?d.transactions.map(x=>`<div class="txn"><div><b>1 Credit</b><small>₹${x.amount} • ${new Date(x.createdAt).toLocaleString()}</small></div><b class="ok">PAID</b></div>`).join(""):`<div class="panel"><p>No transactions yet.</p></div>`}catch(e){}
}
async function redeemCoupon(){const code=$("couponCode").value;try{const d=await api("/api/coupon/redeem",{method:"POST",body:JSON.stringify({code})});toast(`✓ ${d.credits} credit added`);refreshMe()}catch(e){toast(e.message)}}
$("upiId").textContent="ratan143@fam";
renderPackages();syncBuy();refreshMe();show("landing");
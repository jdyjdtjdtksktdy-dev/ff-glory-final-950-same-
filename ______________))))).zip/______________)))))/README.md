# FF GLORY — complete ready project

This build recreates the mobile-first flow visible in the supplied reference video:
- Login / Register
- Dashboard
- Credits
- Buy Credit
- Quantity selector 1–10 at ₹95 per quantity (₹95 to ₹950)
- Dynamic UPI QR payment
- Automatic payment verification
- Automatic fulfilment: EXACTLY 1 credit per verified successful payment, regardless of quantity/amount
- Transaction history
- Gift coupon page
- Launch Bot section
- Contact page
- Mobile bottom navigation

## Payment integration
This project is wired to FamGateway's server-side API. The secret key is kept in `.env`, never in browser JavaScript.

The payment flow is:
Buy Credit → choose quantity 1–10 → create dynamic order → show QR → customer pays → server checks gateway status every 3 seconds → only a gateway-verified success with matching amount is fulfilled once → EXACTLY 1 credit is added.

## Run
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run:
   npm install
   npm start
4. Open:
   http://localhost:3000

## Important security note
The `.env` in this package contains the API credential that was supplied in the chat. Do not publish this ZIP or commit `.env` to GitHub. Because the credential was shared in chat, rotate/revoke it and replace it with a fresh key before public production use.

## Production
Use HTTPS and a real hosting provider. The app's JSON database is suitable for a small prototype, but a production deployment should use a proper database and server-side session store.
